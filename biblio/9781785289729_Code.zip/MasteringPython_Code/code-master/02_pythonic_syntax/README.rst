Chapter 2, Pythonic Syntax
##############################################################################

| Common Pitfalls and Style Guide explains what Pythonic code is and how to write code that is Pythonic and adheres to the Python philosophy.
