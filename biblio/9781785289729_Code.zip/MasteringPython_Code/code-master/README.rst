Code samples for the Mastering Python book
##############################################################################

Code samples from Mastering Python 
(https://www.packtpub.com/application-development/mastering-python)

All of the code in this repository is tested using the bundled tests. To run
the tests yourself simply install the requirements and run the tests:

    pip3 install --upgrade --requirement requirements.txt
    py.test

------------------------------------------------------------------------------

If you are interested in more packages from the author, take a look at his
Github account: https://github.com/WoLpH/
