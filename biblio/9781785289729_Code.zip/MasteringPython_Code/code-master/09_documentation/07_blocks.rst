.. code:: python

   def spam(*args):
       print('spam got args', args)

------------------------------------------------------------------------------

.. math::

    \int_a^b f(x)\,dx = F(b) - F(a)

------------------------------------------------------------------------------

Before comments

.. Everything here will be commented
   
   And this as well
   
   .. code:: python
   
      def even_this_code_sample():
          pass  # Will be commented

After comments

------------------------------------------------------------------------------

Normal text

    Quoted text
