spam module
===========

.. automodule:: spam
    :members:
    :undoc-members:
    :show-inheritance:
