eggs module
===========

.. automodule:: eggs
    :members:
    :undoc-members:
    :show-inheritance:
