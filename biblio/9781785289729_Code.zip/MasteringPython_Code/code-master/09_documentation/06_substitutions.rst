.. |python| image:: python.png
   :scale: 1

The Python programming language uses the logo: |python|

------------------------------------------------------------------------------

.. |author| replace:: Rick van Hattem

This book was written by |author|
