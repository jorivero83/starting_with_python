Chapter 9, Documentation
##############################################################################

| reStructuredText, Napoleon and How to Use Sphinx shows how you can make Sphinx automatically document your code with very little effort. Additionally, it shows how the Napoleon syntax can be used to document function arguments in a way that is legible both in the code and the documentation.
