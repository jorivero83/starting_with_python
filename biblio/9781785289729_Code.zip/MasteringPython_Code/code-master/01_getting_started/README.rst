Chapter 1, Getting started
##############################################################################

| One Environment per Project introduces virtual Python environments using virtualenv or venv to isolate the packages in your Python projects.
