Chapter 8, Metaclasses
##############################################################################

| Making Classes (not instances) Smarter goes deeper into the creation of classes and how class behavior can be completely modified.
