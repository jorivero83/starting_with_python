import abc


class ABC(metaclass=abc.ABCMeta):
    pass
