from . import base


class Eggs(base.Plugin):
    name = 'eggs'

