from . import base


class Spam(base.Plugin):
    name = 'spam'

