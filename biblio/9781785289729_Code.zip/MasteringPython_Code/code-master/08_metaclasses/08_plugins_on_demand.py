import plugins
print(plugins.PluginsOnDemand.get('spam'))
