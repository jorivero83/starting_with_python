Chapter 13, Multiprocessing
##############################################################################

| When a Single CPU Core is not Enough the multiprocessing library can be used to execute your code not just on multiple processors but even on multiple machines.
