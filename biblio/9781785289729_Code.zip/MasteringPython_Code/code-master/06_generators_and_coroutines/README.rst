Chapter 6, Generators and Coroutines
##############################################################################

| Infinity One Step at a Time shows how generators and coroutines can be used to lazily evaluate structures of infinite size.
