Welcome to Mastering Python's documentation!
============================================

Contents:

.. toctree::
   :maxdepth: 2

   README

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

