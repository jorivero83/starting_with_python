Chapter 10, Testing and Logging
##############################################################################

| Preparing for Bugs explains how code can be tested and how logging can be added to enable easy debugging in the case of bugs at a later time.
