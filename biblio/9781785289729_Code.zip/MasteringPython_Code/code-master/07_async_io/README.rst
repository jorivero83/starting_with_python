Chapter 7, Async IO
##############################################################################

| Multithreading without Threads demonstrates the usage of asynchronous functions using async def and await so external resources no longer stall your Python processes.
