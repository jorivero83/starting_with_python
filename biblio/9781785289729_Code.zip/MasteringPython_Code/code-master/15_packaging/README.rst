Chapter 15, Packaging
##############################################################################

| Creating your own Libraries/Applications demonstrates the usage of setuptools and setup.py to build and deploy packages to the Python Package Index (PyPI).
