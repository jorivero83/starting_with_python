import sys


def main():
    print('Args:', sys.argv)

