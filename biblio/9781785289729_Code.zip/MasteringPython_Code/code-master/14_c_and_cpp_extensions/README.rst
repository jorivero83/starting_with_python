Chapter 14, C/C++ Extensions
##############################################################################

| System Calls and C/C++ Libraries covers the calling of C/C++ functions for both interoperability and performance using Ctypes, CFFI and native C/C++.
